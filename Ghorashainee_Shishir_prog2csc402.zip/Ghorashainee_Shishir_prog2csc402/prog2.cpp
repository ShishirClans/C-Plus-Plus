#include "ATM.h"
#include <fstream>
using namespace std;
int main() {
    ifstream inf;
    string filename;

    cout << "Enter the file name: ";
    cin >> filename;
    inf.open(filename);

    if (!inf) {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    Bank bk;
    bk.loadAccounts(inf);
    inf.close();

    ATM atm(bk);
    int result = atm.start();

    switch (result) {
        case 1:
            cout << "Account not found - system shutting down\n";
        break;
        default:
            cout << "Normal Exit\n";
        break;
    }

    return 0;
}
